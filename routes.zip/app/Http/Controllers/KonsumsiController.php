<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class KonsumsiController extends Controller
{
    //
}
